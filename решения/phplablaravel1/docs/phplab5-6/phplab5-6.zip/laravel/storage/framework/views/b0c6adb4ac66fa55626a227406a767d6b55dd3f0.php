<html><head>
    <link rel=stylesheet href='<?php echo e(asset('style.css')); ?>' type='text/css'>
    <title>Резюме и вакансии </title></head><body>

<div class="header"><!--*****************Логотип и шапка********************-->
    Резюме и вакансии<div id="logo"></div>
</div>

<div class="leftcol"><!--**************Основное содержание страницы************-->
    <h1>Программист</h1>


    <p class="pinline second">
        <?php echo e($fio); ?><br>
        Телефон: <?php echo e($phone); ?>

    </p>
    <p  class="pinline third">
        Стаж:
        <?php echo e($stazh); ?>

    </p>

</div>

<div class="rightcol"><!--*******************Навигационное меню*******************-->
    <ul class="menu">
        <li><a href="http://phplab5-6/laravel/public/show">Вакансии</a></li>
        <li><a href="">Резюме по профессиям</a></li>
        <li><a href="">Резюме по возрасту</a></li>
        <li><a href="http://phplab5-6/laravel/public/resume">Избранное резюме</a></li>
        <li><a href="http://phplab5-6/laravel/public/add-content">Добавить резюме</a></li>
    </ul>
</div>
<div class="footer">&copy; Copyright 2017</div>

</body></html>
<?php /**PATH C:\OpenServer\domains\phplab5-6\laravel\resources\views/resume.blade.php ENDPATH**/ ?>