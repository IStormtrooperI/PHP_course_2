<?php

namespace App\Http\Controllers;
//namespace App\Models;

use Illuminate\Http\Request;
use App\Models\Person;
use App\Models\Staff;

class IndexController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $header = "Резюме и вакансии";
        $message = "message";
        return view('page')->with(['header' => $header, 'message' => $message]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $staff = Staff::all();

        return view('add-content')->with(["s"=>$staff]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,
            ['FIO'=>'required|max:255',
                'Phone'=>'required',
                'Stage'=>'required',
                'Staff'=>'required',
                'Image'=>'required']);
        //dump($request->all());
        $data = $request->all();
        $person = Person::create($data);
        //$resume = new Person;
        //$resume->fill($data);
        //dump($resume);
       // $resume->save();
        return redirect('/add-content');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
//    public function show($id)
//    {
//        //
//    }


    public function show()
    {
        $fio = "Иванов Иван";
        $phone = "111111";
        $stazh = "10 лет";

        return view('resume')->with(
            [
                'fio' => $fio,
                'phone' => $phone,
                'stazh' => $stazh
            ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
