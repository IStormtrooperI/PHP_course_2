<html>
<head>
    <link rel=stylesheet href='{{asset('style.css')}}' type='text/css'>
    <title>Резюме и вакансии </title></head>
<body>

<div class="header"><!--*****************Логотип и шапка********************-->
    Резюме и вакансии
    <div id="logo"></div>
</div>

<div class="leftcol"><!--**************Основное содержание страницы************-->


    <form method="POST" action="{{route('resumeStore')}}">
        <p>Введите данные резюме</p>
        <label><input type="text" name="FIO"> :ФИО</label><br>

        <!--<label><input type="text" name="Staff"> :Должность</label><br>-->

        <select name="Staff">
            <option disabled selected>Выберите должность</option>
            @foreach($s as $staff)
            <option value="{{$staff['id']}}">{{$staff['staff']}}</option>
            @endforeach
        </select><br>

        <label><input type="text" name="Phone"> :Телефон</label><br>

        <label><input type="text" name="Stage"> :Стаж</label><br>

        <label><input type="file" name="Image"> :Image</label><br>

        <br><br><input type="submit" value="Ввод">
        {{ csrf_field() }}
    </form>


</div>

<div class="rightcol"><!--*******************Навигационное меню*******************-->
    <ul class="menu">
        <li><a href="http://localhost/laravel/public/show">Вакансии</a></li>
        <li><a href="">Резюме по профессиям</a></li>
        <li><a href="">Резюме по возрасту</a></li>
        <li><a href="http://localhost/laravel/public/resume">Избранное резюме</a></li>
        <li><a href="http://localhost/laravel/public/add-content">Добавить резюме</a></li>
    </ul>
</div>
<div class="footer">&copy; Copyright 2017</div>

</body>
</html>
