<html>
<head>
    <link rel=stylesheet href="<?php echo e(asset('style.css')); ?>" type='text/css'>
    <title><?php echo e($header); ?></title></head>
<body>

<div class="header"><!--*****************Логотип и шапка********************-->
    Резюме и вакансии
    <div id="logo"></div>
</div>

<div class="message">
    <?php echo e($message); ?>

</div>

<div class="leftcol"><!--**************Основное содержание страницы************-->

    <?php if(!isset($person)): ?>
        <div class="pinline1">
            <img class="pic" src="<?php echo e(asset('images/ava1.jpg')); ?>">
        </div>

        <p class="pinline second">
            Иванов Иван

            <br>
            Телефон:
            111111

        </p>

        <p class="pinline third">
            Программист
            <br>

            Стаж:
            10 лет

        </p>
    <?php else: ?>
        <div class="resume">
            <img class="pic" src="<?php echo e(asset('images/'. $person->Image )); ?>">
            <br>
            <p class="pinline second">
                <?php echo e($person->FIO); ?>


                <br>
                Телефон:
                <?php echo e($person->Phone); ?>


            </p>
            <br>
            <p class="pinline third">
                <?php echo e($staff->staff); ?>

                <br>

                Стаж:
                <?php echo e($person->Stage); ?> лет

            </p>
        </div>
    <?php endif; ?>
</div>

<div class="rightcol"><!--*******************Навигационное меню*******************-->
    <ul class="menu">
        <li><a href="<?php echo e(route('resumes')); ?>">Вакансии</a></li>
        <li><a href="<?php echo e(route('resumeStaff')); ?>">Резюме по профессиям</a></li>
        <li><a href="<?php echo e(route('resumeAge')); ?>">Резюме по возрасту</a></li>
        <li><a href="<?php echo e(route('resumeShowMy')); ?>">Избранное резюме</a></li>
        <li><a href="<?php echo e(route('add-content')); ?>">Добавить резюме</a></li>
    </ul>
</div>
<div class="footer">&copy; Copyright 2017</div>

</body>
</html>
<?php /**PATH C:\OpenServer\domains\phplablaravel1\laravel\resources\views/page.blade.php ENDPATH**/ ?>