<html><head>
    <link rel=stylesheet href='<?php echo e(asset('style.css')); ?>' type='text/css'>
    <title>Резюме и вакансии </title></head><body>

<div class="header"><!--*****************Логотип и шапка********************-->
    Резюме и вакансии<div id="logo"></div>
</div>

<div class="leftcol"><!--**************Основное содержание страницы************-->

    <?php if(isset($persons)): ?>
        <table>
            <tr><th>ФИО</th><th>Стаж</th></tr>
            <?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr><td><?php echo e($person['FIO']); ?></td><td><?php echo e($person['Stage']); ?></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php endif; ?>

</div>

<div class="rightcol"><!--*******************Навигационное меню*******************-->
    <ul class="menu">
        <li><a href="<?php echo e(route('resumes')); ?>">Вакансии</a></li>
        <li><a href="<?php echo e(route('resumeStaff')); ?>">Резюме по профессиям</a></li>
        <li><a href="<?php echo e(route('resumeAge')); ?>">Резюме по возрасту</a></li>
        <li><a href="<?php echo e(route('resumeShowMy')); ?>">Избранное резюме</a></li>
        <li><a href="<?php echo e(route('add-content')); ?>">Добавить резюме</a></li>
    </ul>
</div>
<div class="footer">&copy; Copyright 2017</div>

</body></html>
<?php /**PATH C:\OpenServer\domains\phplablaravel1\laravel\resources\views/resumeage.blade.php ENDPATH**/ ?>