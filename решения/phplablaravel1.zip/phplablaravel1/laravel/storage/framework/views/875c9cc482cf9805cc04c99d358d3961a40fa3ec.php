<html>
<head>
    <link rel=stylesheet href='<?php echo e(asset('style.css')); ?>' type='text/css'>
    <title>Резюме и вакансии </title></head>
<body>

<div class="header"><!--*****************Логотип и шапка********************-->
    Резюме и вакансии
    <div id="logo"></div>
</div>

<div class="leftcol"><!--**************Основное содержание страницы************-->


    <form method="POST" action="<?php echo e(route('resumeStore')); ?>">
        <p>Введите данные резюме</p>
        <label><input type="text" name="FIO"> :ФИО</label><br>

        <!--<label><input type="text" name="Staff"> :Должность</label><br>-->

        <select name="Staff">
            <option disabled selected>Выберите должность</option>
            <?php $__currentLoopData = $s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($staff['id']); ?>"><?php echo e($staff['staff']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br>

        <label><input type="text" name="Phone"> :Телефон</label><br>

        <label><input type="text" name="Stage"> :Стаж</label><br>

        <label><input type="file" name="Image"> :Image</label><br>

        <br><br><input type="submit" value="Ввод">
        <?php echo e(csrf_field()); ?>

    </form>


</div>

<div class="rightcol"><!--*******************Навигационное меню*******************-->
    <ul class="menu">
        <li><a href="http://localhost/laravel/public/show">Вакансии</a></li>
        <li><a href="">Резюме по профессиям</a></li>
        <li><a href="">Резюме по возрасту</a></li>
        <li><a href="http://localhost/laravel/public/resume">Избранное резюме</a></li>
        <li><a href="http://localhost/laravel/public/add-content">Добавить резюме</a></li>
    </ul>
</div>
<div class="footer">&copy; Copyright 2017</div>

</body>
</html>
<?php /**PATH W:\domains\localhost\laravel\resources\views/add-content.blade.php ENDPATH**/ ?>