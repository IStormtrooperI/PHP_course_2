<html>
<head>
    <link rel=stylesheet href='<?php echo e(asset('style.css')); ?>' type='text/css'>
    <title>Резюме и вакансии </title></head>
<body>

<div class="header"><!--*****************Логотип и шапка********************-->
    Резюме и вакансии
    <div id="logo"></div>
</div>

<div class="leftcol"><!--**************Основное содержание страницы************-->

    <?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="pinline second" style="border: 1px solid green; padding:10px">
            <?php echo e($person['FIO']); ?>,
            Телефон: <?php echo e($person['Phone']); ?>


            <span class="pinline third">
                Стаж: <?php echo e($person['Stage']); ?> лет
            </span>
            <a href="<?php echo e(route('resumeShow',['id'=>$person->id])); ?>">Подробнее</a>
        <form action="<?php echo e(route('resumeDelete',['person'=>$person->id])); ?>" method="POST">
            <input type="hidden" name="_method" value="DELETE">
            <input type="submit" value="Удалить">
            <?php echo e(csrf_field()); ?>

        </form>
        </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>

<div class="rightcol"><!--*******************Навигационное меню*******************-->
    <ul class="menu">
        <li><a href="<?php echo e(route('resumes')); ?>">Вакансии</a></li>
        <li><a href="<?php echo e(route('resumeStaff')); ?>">Резюме по профессиям</a></li>
        <li><a href="<?php echo e(route('resumeAge')); ?>">Резюме по возрасту</a></li>
        <li><a href="<?php echo e(route('resumeShowMy')); ?>">Избранное резюме</a></li>
        <li><a href="<?php echo e(route('add-content')); ?>">Добавить резюме</a></li>
        <li><a href="<?php echo e(route('first')); ?>">Вакансии со стажем 5-15 лет</a></li>
        <li><a href="<?php echo e(route('second')); ?>">Вакансии Программистов</a></li>
        <li><a href="<?php echo e(route('third')); ?>">Общее число резюме</a></li>
        <li><a href="<?php echo e(route('fourth')); ?>">Представители каких профессий есть в списк резюме</a></li>
    </ul>
</div>
<div class="footer">&copy; Copyright 2017</div>

</body>
</html>
<?php /**PATH C:\OpenServer\domains\phplablaravel1\laravel\resources\views/resume.blade.php ENDPATH**/ ?>