<?php
$link = mysqli_connect("localhost", "mysql", "mysql", "phplab2") or die("Ошибка " . mysqli_error($link));
?>